java -Xmx256m -jar MonProtegemed.jar
