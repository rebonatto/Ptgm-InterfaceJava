<?php phpinfo(); ?> 

